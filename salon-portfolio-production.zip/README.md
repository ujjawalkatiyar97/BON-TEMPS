
Salon Portfolio - Ready-to-deploy Vite + React project
-----------------------------------------------------

Files included:
- package.json
- index.html
- src/main.jsx
- src/SalonPortfolio.jsx (main component)
- src/styles.css
- README.md

How to run locally:
1. cd salon-portfolio-project
2. npm install
3. npm run dev
4. Open http://localhost:5173

Tailwind CSS:
- The project uses Tailwind classes in the component. To enable Tailwind, run:
  npx tailwindcss init -p
  and follow the Tailwind + Vite setup: https://tailwindcss.com/docs/guides/vite

Deployment (Vercel):
1. Push repo to GitHub
2. Import project at https://vercel.com/new and select Vite framework
3. Deploy

Design notes (inspired by Bon Temps salon research):
- Bon Temps uses deep jewel tones (navy/teal), wine/maroon accents and metallic finishes. Use:
  Primary: #0f5060 (deep teal) or #0b3a4b (navy-teal)
  Accent: #b02a4a (wine/maroon)
  Soft: #f8f3ef (cream)
  Metallic hint: #c0a080

License: Replace placeholder images and links before production.



Production-ready deploy options
------------------------------

1) **Vercel (recommended)**:
   - Push repository to GitHub.
   - Visit https://vercel.com/new and import your repo (select Project > Framework Preset: Vite).
   - Vercel will automatically build with `npm run build` and serve the `dist` folder.

2) **Netlify**:
   - Create a Netlify site, link your GitHub repo, set build command: `npm run build` and publish directory: `dist`.
   - Add a `_redirects` or use the provided `netlify.toml` to route SPA routes to index.html.

3) **Docker**:
   - Build: `docker build -t salon-portfolio .`
   - Run: `docker run -p 8080:80 salon-portfolio` and open http://localhost:8080

Notes about assets and brand:
- Replace placeholder images in `src/SalonPortfolio.jsx` with your own high-resolution images.
- Replace contact details and booking links.
- Update `og-image.png` and `favicon.ico` with your branding assets.

Security and automation notes:
- Do NOT commit secrets to the repo. Use platform env variables for API keys.
- If you want automatic deployment to Vercel on push, connect Vercel to your GitHub and enable automatic deploys.
