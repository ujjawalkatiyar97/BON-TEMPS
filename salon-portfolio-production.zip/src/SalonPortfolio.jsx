import React from "react";
import { motion } from "framer-motion";

const services = [
  { id: 1, name: "Haircut & Styling", price: "₹499", desc: "Precision cuts for all hair types; styling included." },
  { id: 2, name: "Color & Highlights", price: "From ₹999", desc: "Creative colour, balayage and subtle highlights." },
  { id: 3, name: "Bridal & Event Makeup", price: "From ₹2,499", desc: "Full glam for your big day — trials available." },
  { id: 4, name: "Facials & Skincare", price: "From ₹399", desc: "Personalised skin consultations and nourishing facials." },
  { id: 5, name: "Gents Grooming", price: "From ₹299", desc: "Cuts, beard styling and hot towel shaves." },
];

const team = [
  { id: 1, name: "Aisha Kapoor", role: "Lead Stylist", insta: "https://instagram.com/aisha" , img: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=800&auto=format&fit=crop&crop=faces"},
  { id: 2, name: "Rohit Sharma", role: "Senior Colourist", insta: "https://instagram.com/rohit" , img: "https://images.unsplash.com/photo-1545996124-1e37f6b7d3a8?q=80&w=800&auto=format&fit=crop&crop=faces"},
  { id: 3, name: "Meera Joshi", role: "Makeup Artist", insta: "https://instagram.com/meera" , img: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?q=80&w=800&auto=format&fit=crop&crop=faces"},
];

const gallery = [
  "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1556228720-1b4d32fcf9b6?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1556228720-4b1e2b3f5f7a?q=80&w=1200&auto=format&fit=crop",
];

export default function SalonPortfolio() {
  return (
    <div className="min-h-screen text-gray-800" style={{background: "var(--soft)"}}>
      <header className="header-gradient">
        <div className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-white/30 flex items-center justify-center font-bold text-xl text-white">SS</div>
            <div>
              <h1 className="text-white text-2xl font-extrabold tracking-tight">Salon Studio — Unisex</h1>
              <p className="text-white/90 text-sm">Where style meets comfort</p>
            </div>
          </div>
          <nav className="hidden md:flex gap-6 items-center text-white">
            <a href="#services" className="hover:underline">Services</a>
            <a href="#gallery" className="hover:underline">Gallery</a>
            <a href="#team" className="hover:underline">Team</a>
            <a href="#booking" className="hover:underline">Booking</a>
            <a href="#contact" className="bg-white/20 px-4 py-2 rounded-full">Contact</a>
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-12">
        <section className="grid md:grid-cols-2 gap-8 items-center">
          <motion.div initial={{ x: -30, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ duration: 0.6 }}>
            <h2 className="text-4xl font-extrabold mb-4">A modern unisex salon — tailored services, premium care.</h2>
            <p className="text-lg text-gray-600 mb-6">From precision cuts to bridal glam, we craft looks that fit your personality. Book online or walk in — we're ready.</p>

            <div className="flex gap-3">
              <a href="#booking" className="btn-primary">Book Appointment</a>
              <a href="#services" className="btn-outline">View Services</a>
            </div>

            <div className="mt-6 text-sm text-gray-500">Open: Mon–Sat 10:00 — 20:00 • Phone: <a href="tel:+911234567890" className="text-indigo-600">+91 12345 67890</a></div>
          </motion.div>

          <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.6 }}>
            <div className="rounded-xl overflow-hidden shadow-lg">
              <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=1400&auto=format&fit=crop" alt="salon" className="w-full h-80 object-cover" />
            </div>
          </motion.div>
        </section>

        <section id="services" className="mt-16">
          <h3 className="text-2xl font-bold mb-4">Services</h3>
          <p className="text-gray-600 mb-6">We offer a wide range of salon services for all genders — packages for students, professionals and bridal bookings.</p>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {services.map(s => (
              <div key={s.id} className="bg-white rounded-xl p-5 shadow-sm">
                <h4 className="font-semibold text-lg">{s.name}</h4>
                <p className="text-sm text-gray-500 mb-3">{s.desc}</p>
                <div className="flex items-center justify-between">
                  <div className="text-indigo-600 font-bold">{s.price}</div>
                  <a href="#booking" className="text-sm underline">Book</a>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section id="gallery" className="mt-16">
          <h3 className="text-2xl font-bold mb-4">Gallery</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {gallery.map((g, i) => (
              <div key={i} className="rounded-lg overflow-hidden shadow-md">
                <img src={g} alt={`gallery-${i}`} className="w-full h-48 object-cover" />
              </div>
            ))}
          </div>
        </section>

        <section id="team" className="mt-16">
          <h3 className="text-2xl font-bold mb-4">Meet the Team</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {team.map(member => (
              <div key={member.id} className="bg-white p-5 rounded-xl shadow-sm flex gap-4 items-center">
                <img src={member.img} alt={member.name} className="w-20 h-20 rounded-full object-cover" />
                <div>
                  <div className="font-semibold">{member.name}</div>
                  <div className="text-sm text-gray-500">{member.role}</div>
                  <a href={member.insta} target="_blank" rel="noreferrer" className="text-sm text-pink-500 mt-2 inline-block">Instagram</a>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section id="booking" className="mt-16 bg-white p-8 rounded-xl shadow-md">
          <h3 className="text-2xl font-bold mb-4">Quick Booking</h3>
          <p className="text-gray-600 mb-4">Fill the quick form or click \"Book Online\" to go to our booking page.</p>

          <form action="https://example.com/booking" method="GET" className="grid sm:grid-cols-2 gap-4">
            <input name="name" placeholder="Your name" className="p-3 border rounded" required />
            <input name="phone" placeholder="Phone or WhatsApp" className="p-3 border rounded" required />
            <input name="email" placeholder="Email (optional)" className="p-3 border rounded" />
            <select name="service" className="p-3 border rounded">
              <option>Choose service</option>
              {services.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
            </select>
            <textarea name="notes" placeholder="Any notes (allergies, requests)" className="p-3 border rounded sm:col-span-2" />

            <div className="sm:col-span-2 flex gap-3">
              <button type="submit" className="btn-primary">Submit request</button>
              <a href="https://calendly.com/your-salon-demo" target="_blank" rel="noreferrer" className="px-5 py-3 border rounded-lg">Book Online (Calendly)</a>
            </div>
          </form>
        </section>

        <section id="contact" className="mt-16">
          <h3 className="text-2xl font-bold mb-4">Contact & Location</h3>
          <div className="grid md:grid-cols-2 gap-6 items-start">
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <p className="mb-2">Address: 12 Rose Lane, MG Road, City — 110001</p>
              <p className="mb-2">Phone: <a href="tel:+911234567890" className="text-indigo-600">+91 12345 67890</a></p>
              <p className="mb-2">Email: <a href="mailto:hello@salonstudio.example" className="text-indigo-600">hello@salonstudio.example</a></p>

              <div className="mt-4 flex gap-3">
                <a href="https://instagram.com/your-salon" target="_blank" rel="noreferrer" className="underline">Instagram</a>
                <a href="https://facebook.com/your-salon" target="_blank" rel="noreferrer" className="underline">Facebook</a>
                <a href="https://wa.me/911234567890" target="_blank" rel="noreferrer" className="underline">WhatsApp</a>
              </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h4 className="font-semibold mb-2">Opening Hours</h4>
              <ul className="text-sm text-gray-600">
                <li>Mon — Sat: 10:00 — 20:00</li>
                <li>Sunday: Closed / Appointments only</li>
              </ul>

              <div className="mt-4">
                <iframe title="map" className="w-full h-48 border rounded" src="https://www.google.com/maps?q=MG+Road+City&output=embed" />
              </div>
            </div>
          </div>
        </section>

        <footer className="mt-16 py-8 text-center text-sm text-gray-500">
          <div>© {new Date().getFullYear()} Salon Studio — Built with ❤️ • <a href="#contact" className="underline">Get in touch</a></div>
        </footer>
      </main>
    </div>
  );
}
