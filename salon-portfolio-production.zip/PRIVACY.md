
Privacy Policy (placeholder)
----------------------------
This is a sample privacy policy. Replace with your legal text.
- We do not sell personal data.
- Booking form data will be stored by the booking provider you configure.
